PanPan Store
E-commerce de acessórios para pets (projeto escolar)

Banco de dados:
Nome: panpan_store
Estrutura criada no phpMyAdmin
Arquivo: panpan_store.sql

O projeto é 100% front-end (HTML/CSS),
e o banco foi desenvolvido para futura integração com PHP.

Para visualizar:
Abra index.html
